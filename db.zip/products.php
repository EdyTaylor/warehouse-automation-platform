<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require 'db.php';
$db = getDB();


// 🔥 НОРМАЛИЗАЦИЯ ЧИСЕЛ (добавили)
function normalizeNumber($value) {
    $value = str_replace(' ', '', $value);
    $value = str_replace(',', '.', $value);
    return $value === '' ? 0 : $value;
}


// 🔥 УДАЛЕНИЕ (НЕ ТРОГАЛИ)
if (isset($_GET['delete_id'])) {
    $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([intval($_GET['delete_id'])]);
    header("Location: products.php");
    exit;
}


// 🔥 РЕДАКТИРОВАНИЕ (НЕ ТРОГАЛИ)
$editProduct = null;

if (isset($_GET['edit_id'])) {
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([intval($_GET['edit_id'])]);
    $editProduct = $stmt->fetch(PDO::FETCH_ASSOC);
}


// 🔥 СОХРАНЕНИЕ (только добавили normalize)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!empty($_POST['id'])) {

        $stmt = $db->prepare("
            UPDATE products SET
                name = ?,
                roll_length = ?,
                price_per_meter = ?,
                purchase_price = ?,
                delivery_price = ?,
                price_1_4 = ?,
                price_5_9 = ?,
                price_10_19 = ?,
                price_20_plus = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $_POST['name'],
            $_POST['roll_length'],
            normalizeNumber($_POST['price_per_meter']),
            normalizeNumber($_POST['purchase_price']),
            normalizeNumber($_POST['delivery_price']),
            normalizeNumber($_POST['price_1_4']),
            normalizeNumber($_POST['price_5_9']),
            normalizeNumber($_POST['price_10_19']),
            normalizeNumber($_POST['price_20_plus']),
            $_POST['id']
        ]);

    } else {

        $stmt = $db->prepare("
            INSERT INTO products 
            (name, roll_length, price_per_meter, purchase_price, delivery_price,
             price_1_4, price_5_9, price_10_19, price_20_plus)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $_POST['name'],
            $_POST['roll_length'],
            normalizeNumber($_POST['price_per_meter']),
            normalizeNumber($_POST['purchase_price']),
            normalizeNumber($_POST['delivery_price']),
            normalizeNumber($_POST['price_1_4']),
            normalizeNumber($_POST['price_5_9']),
            normalizeNumber($_POST['price_10_19']),
            normalizeNumber($_POST['price_20_plus'])
        ]);
    }

    header("Location: products.php");
    exit;
}


// 🔥 СПИСОК (НЕ ТРОГАЛИ)
$products = $db->query("SELECT * FROM products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);


// 🔥 ВАЖНО: МЕНЮ ВНИЗУ (чтобы не было header ошибки)
require 'menu.php';
?>

<h2>📦 Товары</h2>

<form method="POST">

    <input type="hidden" name="id" value="<?= $editProduct['id'] ?? '' ?>">

    <input name="name" placeholder="Название" 
           value="<?= $editProduct['name'] ?? '' ?>" required><br><br>

    <input name="roll_length" placeholder="Метраж рулона" 
           value="<?= $editProduct['roll_length'] ?? '' ?>" required><br><br>

    <input class="money" name="price_per_meter" placeholder="Цена за метр"
           value="<?= $editProduct['price_per_meter'] ?? '' ?>"><br>

    <input class="money" name="purchase_price" placeholder="Себестоимость"
           value="<?= $editProduct['purchase_price'] ?? '' ?>"><br>

    <input class="money" name="delivery_price" placeholder="С доставкой"
           value="<?= $editProduct['delivery_price'] ?? '' ?>"><br><br>

    <b>Цены по количеству:</b><br>

    <input class="money" name="price_1_4" placeholder="1-4 рулона"
           value="<?= $editProduct['price_1_4'] ?? '' ?>"><br>

    <input class="money" name="price_5_9" placeholder="5-9 рулонов"
           value="<?= $editProduct['price_5_9'] ?? '' ?>"><br>

    <input class="money" name="price_10_19" placeholder="10-19 рулонов"
           value="<?= $editProduct['price_10_19'] ?? '' ?>"><br>

    <input class="money" name="price_20_plus" placeholder="20+ рулонов"
           value="<?= $editProduct['price_20_plus'] ?? '' ?>"><br><br>

    <button>
        <?= $editProduct ? '💾 Обновить' : 'Сохранить' ?>
    </button>

</form>


<h3>Список товаров</h3>

<table border="1">
<tr>
    <th>ID</th>
    <th>Название</th>
    <th>Метраж</th>
    <th>Цена/м</th>
    <th>Себестоимость</th>
    <th>С доставкой</th>
    <th>1-4</th>
    <th>5-9</th>
    <th>10-19</th>
    <th>20+</th>
    <th>✏️</th>
    <th>❌</th>
</tr>

<?php foreach ($products as $p): ?>
<tr>
    <td><?= $p['id'] ?></td>
    <td><?= $p['name'] ?></td>
    <td><?= $p['roll_length'] ?></td>
    <td><?= $p['price_per_meter'] ?></td>
    <td><?= $p['purchase_price'] ?></td>
    <td><?= $p['delivery_price'] ?></td>

    <td><?= $p['price_1_4'] ?></td>
    <td><?= $p['price_5_9'] ?></td>
    <td><?= $p['price_10_19'] ?></td>
    <td><?= $p['price_20_plus'] ?></td>

    <td>
        <a href="?edit_id=<?= $p['id'] ?>">✏️</a>
    </td>

    <td>
        <a href="?delete_id=<?= $p['id'] ?>" onclick="return confirm('Удалить?')">
            ❌
        </a>
    </td>
</tr>
<?php endforeach; ?>
</table>


<!-- 🔥 АВТО-ФОРМАТ (ДОБАВИЛИ, НЕ ЛОМАЕТ НИЧЕГО) -->
<script>
document.querySelectorAll('.money').forEach(input => {

    input.addEventListener('input', function() {
        let val = this.value;

        val = val.replace(/[^0-9,\. ]/g, '');
        val = val.replace(',', '.');

        let parts = val.split('.');
        let integer = parts[0].replace(/\s/g, '');

        integer = integer.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

        this.value = parts.length > 1 ? integer + '.' + parts[1] : integer;
    });

});
</script>