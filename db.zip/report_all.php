<?php
require 'db.php';
$db = getDB();
require 'menu.php';


// 🔥 СВОДКА (за всё время)
$data = $db->query("
    SELECT 
        products.name,
        SUM(sales.quantity) as total_qty,
        SUM(sales.total) as revenue
    FROM sales
    LEFT JOIN products ON products.id = sales.product_id
    GROUP BY products.id
")->fetchAll(PDO::FETCH_ASSOC);


// 🔥 ОБЩИЙ ИТОГ
$total = $db->query("
    SELECT SUM(total) as total_sum 
    FROM sales
")->fetch(PDO::FETCH_ASSOC);


// 🔥 ДЕТАЛИЗАЦИЯ
$details = $db->query("
    SELECT sales.*, products.name
    FROM sales
    LEFT JOIN products ON products.id = sales.product_id
    ORDER BY sales.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>📊 Отчет за всё время</h2>


<!-- 🔹 СВОДКА -->
<h3>Сводка</h3>

<table border="1">
<tr>
    <th>Товар</th>
    <th>Количество</th>
    <th>Выручка</th>
</tr>

<?php foreach ($data as $row): ?>
<tr>
    <td><?= htmlspecialchars($row['name']) ?></td>
    <td><?= $row['total_qty'] ?></td>
    <td><?= $row['revenue'] ?></td>
</tr>
<?php endforeach; ?>
</table>

<h3>Итого за всё время: <?= $total['total_sum'] ?? 0 ?></h3>


<!-- 🔥 ДЕТАЛИЗАЦИЯ -->
<h3>🕒 Все операции</h3>

<table border="1">
<tr>
    <th>Дата</th>
    <th>Время</th>
    <th>Товар</th>
    <th>Тип</th>
    <th>Операция</th>
    <th>Количество</th>
    <th>Цена</th>
    <th>Сумма</th>
    <th>Сделка</th>
</tr>

<?php foreach ($details as $d): ?>
<tr>
    <td><?= date('d.m.Y', strtotime($d['created_at'])) ?></td>
    <td><?= date('H:i:s', strtotime($d['created_at'])) ?></td>
    <td><?= htmlspecialchars($d['name']) ?></td>
    <td><?= htmlspecialchars($d['type']) ?></td>

    <td>
<?php if ($d['type'] == 'reserve'): ?>
    🟡 Резерв
<?php elseif ($d['type'] == 'writeoff'): ?>
    🔴 Списание
<?php else: ?>
    🟢 Продажа
<?php endif; ?>
    </td>

    <td><?= $d['quantity'] ?></td>
    <td><?= $d['price_per_unit'] ?></td>
    <td><?= $d['total'] ?></td>

    <td>
        <?php if (!empty($d['deal_id'])): ?>
            <a href="<?= htmlspecialchars($d['deal_url']) ?>" target="_blank">
                Сделка #<?= intval($d['deal_id']) ?>
            </a>
        <?php else: ?>
            —
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</table>